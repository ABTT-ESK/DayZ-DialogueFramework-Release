// Voice pack for Dialogue Framework.
//
// SERVER OWNERS: this is a TEMPLATE you republish as your own Workshop item.
// Change name/author/authorID below to yours before publishing, and see
// README.md for the (short) signing steps.
//
// You do NOT need to fork or repack the scripts mod to add voice lines --
// that one stays exactly as published, so you keep getting its updates.

name = "Dialogue Framework - Voice Pack";
credits = "";
author = "YourNameHere";
authorID = "0";
version = "1.0.0";
extra = 0;
type = "mod";

// Data-only addon: no script modules, so no dependencies[] entry is needed.
// It deliberately does not require the scripts mod either -- the two are
// decoupled on purpose, so this pack loading (or not) can never stop the
// scripts mod from loading.

picture = "";
logo = "";
logoSmall = "";
logoOver = "";
tooltip = "Voice lines for Dialogue Framework NPC dialogue";

hideName = 0;
hidePicture = 0;
