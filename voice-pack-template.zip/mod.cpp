name = "Dialogue Framework - Voice Pack";
credits = "";
author = "YourNameHere";
authorID = "0";
version = "1.0.0";
extra = 0;
type = "mod";

picture = "";
logo = "";
logoSmall = "";
logoOver = "";
tooltip = "Voice lines for Dialogue Framework";

hideName = 0;
hidePicture = 0;
