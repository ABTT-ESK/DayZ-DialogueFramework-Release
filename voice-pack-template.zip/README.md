# Adding voice lines to your NPCs

This gives your NPCs actual spoken audio. You don't need to write any code —
you record sound files, drop them in a folder, and double-click a script that
does the technical part for you.

**Roughly 20 minutes for your first line, a couple of minutes for each one
after that.**

---

## How it works, in one picture

```
   You record          You drop it in           You double-click
   a sound file   -->  data/audio/dialogues/ --> generate_soundsets.bat
                                                        |
                                                        v
                                              config.cpp is written
                                              for you, automatically
```

Then you pack the folder and upload it to the Steam Workshop once. After
that, adding more lines is just: drop file in, double-click, re-upload.

---

## The one rule that matters

**The name of your sound file is the name you use in your dialogue.**

If you save a file called `peter_hello.ogg`, then in your NPC's dialogue
JSON you write `"peter_hello"`.

```
peter_hello.ogg   ->   "VoiceLineIDs": ["peter_hello"]
```

That's the whole naming system. Get that right and everything else is
mechanical.

Use simple names: letters, numbers and underscores. No spaces, no
apostrophes, no accents.

---

## Step 1 — Get your audio into the right format

DayZ is fussy about audio. Your file must be:

| Setting | Value |
|---|---|
| Format | **OGG** (`.ogg`) |
| Channels | **Mono** — not stereo |
| Sample rate | **44100 Hz** |

**Mono matters.** DayZ places sound in 3D space so it comes from the NPC. A
stereo file plays flat, as if it's inside the player's head.

### Converting with Audacity (free)

1. Download [Audacity](https://www.audacityteam.org/) and open your recording
2. **Tracks → Mix → Mix Stereo Down to Mono**
3. Bottom-left "Project Rate" box → set to **44100**
4. **File → Export → Export as OGG**
5. Save it with the name you want to use as the voice line ID

Whatever you record with is fine — a phone, a headset, a text-to-speech tool.
Audacity just converts it.

---

## Step 2 — Put the file in the folder

Drop your `.ogg` files into:

```
data\audio\dialogues\
```

You can put as many as you like in there. Subfolders aren't supported —
keep them all directly in `dialogues\`.

---

## Step 3 — Double-click `generate_soundsets.bat`

That's it. The script looks at every `.ogg` file in the folder and writes
`config.cpp` for you.

You'll see something like:

```
Scanning ...\data\audio\dialogues
  + peter_hello
  + peter_goodbye
  + trader_greeting_1

Done. 3 voice line(s) written to config.cpp
```

**Never edit `config.cpp` by hand.** The script overwrites it every time it
runs. It keeps a backup as `config.cpp.bak` just in case.

Re-run the script whenever you add, remove or rename a sound file.

---

## Step 4 — Use the names in your dialogue

In your NPC's dialogue file, reference the filenames:

```json
{
  "GreetingVoiceLineIDs": ["peter_hello"],
  "FarewellVoiceLineIDs": ["peter_goodbye"],
  "Nodes": [
    {
      "ID": 1,
      "SpeakerText": "You made it. Not everyone does.",
      "VoiceLineIDs": ["peter_line_1"]
    }
  ]
}
```

Put several in a list and one is picked at random each time — good for
greetings, so an NPC doesn't say the identical thing every visit.

### Quest lines have fixed names

Lines played on the quest screen use names the mod decides, where `<ID>` is
your quest's ID number:

| File to record | When it plays |
|---|---|
| `Quest_101_Start.ogg` | The quest is being offered |
| `Quest_101_InProgress.ogg` | The player is part-way through |
| `Quest_101_Complete.ogg` | Ready to hand in |

Name the files exactly like that and they're picked up automatically.

---

## Step 5 — Pack it and put it on the Workshop

Voice audio has to be downloaded by each player, and the only way to do that
in DayZ is a Steam Workshop item. So this folder becomes **your own mod**,
published under your own name.

You do this **once**. After that, adding lines is just re-uploading.

### 5a. Make it yours

Open `mod.cpp` in Notepad and change:

```
author = "YourNameHere";
```

to your name. That's the only edit needed.

### 5b. Make a signing key

One command, one time. Open a command prompt and run:

```
DSCreateKey.exe MyServerVoices
```

(`DSCreateKey.exe` comes with DayZ Tools.)

You get two files:

| File | What it is |
|---|---|
| `MyServerVoices.bikey` | **Public.** Goes in your server's `keys\` folder |
| `MyServerVoices.biprivatekey` | **Secret.** Keep it. Never share or upload it |

> **Never use someone else's private key**, even if a mod offers one.
> Signature checking exists so your server only accepts approved files. A
> shared private key means anyone can sign anything — including cheats — and
> your server will accept it.

### 5c. Pack it

Open **Addon Builder** (DayZ Tools) and set:

- **Source directory** — this folder
- **Destination** — wherever you want the `.pbo`
- **Sign** — point it at your `.biprivatekey`

One important setting: in Addon Builder's options, find the list of file
types to copy, and make sure it includes `*.ogg`. If it doesn't, your audio
is silently left out of the build.

### 5d. Upload it

Open **Publisher** (DayZ Tools), create a new item, point it at your mod
folder, add a title and a thumbnail, and upload it.

Set it to **Private** first, subscribe to it yourself, and check the audio
works before making it public.

### 5e. Turn it on

- Add your mod to the server's `-mod=` list, **not** `-servermod=`. Voice
  audio is played on the player's machine, so a server-only mod would be
  silent.
- Put your `.bikey` in the server's `keys\` folder
- Players subscribe to your Workshop item

---

## If a line isn't playing

Everything here fails quietly, so check in this order.

**1. Look at the client log.** The mod tells you exactly which lines it
couldn't find:

```
[DialogueFramework] [VOICE-AUDIT] 12 voice line ID(s) checked, 2 with NO matching SoundSet:
[DialogueFramework] [VOICE-AUDIT]   missing: DialogueFW_peter_hello_SoundSet
```

That means your dialogue JSON says `peter_hello` but no matching sound file
was found. Almost always a typo or a file that wasn't in the folder when you
ran the script.

**2. Did you re-run the script** after adding the file?

**3. Is the file really `.ogg`?** Renaming an `.mp3` to `.ogg` doesn't
convert it. Re-export from Audacity.

**4. Is it mono?** A stereo file may play oddly or not at all.

**5. Is the audio actually in the PBO?** Open the built `.pbo` with PBO
Manager and look for `data\audio\dialogues\`. If it's empty, `*.ogg` is
missing from Addon Builder's copy list.

**6. Did you re-upload** after rebuilding?

---

## Common questions

**Do I have to do any of this?**
No. Without a voice pack every line is silent text, and everything else
works normally.

**Can I voice only some lines?**
Yes. Any line without audio is simply silent. Start with greetings — they're
the most noticeable.

**Do players need this mod?**
Yes, if you want them to hear it. Audio plays on their machine.

**Can I use AI or text-to-speech voices?**
Nothing stops you technically. Check the terms of whichever service you use
if your server takes donations.

**Will my NPC's mouth move?**
On AI NPCs, yes — automatically, for as long as the clip lasts. Expansion's
regular (non-AI) NPCs are static and can't animate, so audio plays but they
stand still.

**Do I re-upload for every new line?**
Yes, but it's quick: drop the file in, double-click the script, rebuild,
re-upload. Batch up a few lines and do them together.
