# Dialogue Framework — Voice Pack (template)

**This is a template you republish as your own Steam Workshop item.** You
never fork, repack, or re-sign the scripts mod — it stays as published, so
you keep receiving its updates and bug fixes.

Everything you touch is in this folder.

This is the **only** addon you repack to add or change voice audio. The
scripts addon (`DialogueFramework`) never needs rebuilding for new lines.

## The naming rule

Everything hinges on one convention. A voice line ID of `Foo` requires a
`CfgSoundSets` entry named exactly:

```
DialogueFW_Foo_SoundSet
```

Get this wrong and the line **silently doesn't play** — no crash, no error
in the server log. The scripts addon checks `ConfigIsExisting()` before
playing and logs the exact missing SoundSet name to the **client** script
log (not the server RPT), so that's where to look when a line is silent.

## Two kinds of voice line ID

**1. Authored IDs** — anything you put in your tree JSON:
`GreetingVoiceLineIDs`, `FarewellVoiceLineIDs`, and each node's
`VoiceLineIDs`. You choose these names freely.

**2. Generated IDs** — built by the scripts for the live quest-detail step.
These names are fixed and must match exactly, where `<ID>` is the
Expansion quest ID:

| Voice line ID | When it plays | Quest description slot |
|---|---|---|
| `Quest_<ID>_Start` | Quest is offered | `Descriptions[0]` |
| `Quest_<ID>_InProgress` | Quest is active | `Descriptions[1]` |
| `Quest_<ID>_Complete` | Ready to turn in | `Descriptions[2]` |

So quest 101 needs `DialogueFW_Quest_101_Start_SoundSet`, and so on.
Commented-out templates for exactly these are in `config.cpp`.

## Audio file requirements

- **Format:** `.ogg` (Vorbis)
- **Channels:** mono — DayZ positions sound in 3D from the NPC, and stereo
  files do not position correctly
- **Sample rate:** 44100 Hz
- **Location:** `data/audio/dialogues/`
- **In `samples[]`:** reference the path **without** the `.ogg` extension

## The short version: use `generate_soundsets.bat`

You do **not** have to write config syntax by hand. Drop your `.ogg` files
into `data/audio/dialogues/`, double-click `generate_soundsets.bat`, and it
rewrites `config.cpp` with a matching SoundShader and SoundSet for every
file it finds. **The filename becomes the voice line ID**, so name files
exactly what you reference in your tree JSON (or the fixed
`Quest_<ID>_Start` style names for quest lines). Your previous `config.cpp`
is backed up to `config.cpp.bak` each run.

Then repack and republish. See "Why you still have to repack" below for
why that last step is unavoidable.

## Signing: generate your own key (one time, ~2 minutes)

Because you're publishing your own Workshop item, you sign it with your own
key. This is a one-off — the same key works for every future update.

Using DayZ Tools (its `bin` folder is on your PATH after installing):

```
DSCreateKey.exe MyServerVoices
```

That produces two files:

| File | What it is | Where it goes |
|---|---|---|
| `MyServerVoices.bikey` | **Public.** Safe to hand out | Your server's `keys/` folder |
| `MyServerVoices.biprivatekey` | **Secret. Never share this** | Keep it local, in `Keys/` here (gitignored) |

Then point Addon Builder's signing option at the `.biprivatekey`, or sign
manually after packing:

```
DSSignFile.exe MyServerVoices.biprivatekey DialogueFramework_SoundSets.pbo
```

### Why you shouldn't use somebody else's private key

You'll occasionally see mods ship a `.biprivatekey` "for convenience."
Don't rely on that, and don't redistribute yours. Signature checking exists
so a server only accepts client PBOs signed by a key in its `keys/` folder.
The moment a private key is public, **anyone can sign anything with it** —
including a cheat build — and every server trusting that key will accept
it. Generating your own takes one command and closes that hole entirely.

## Publishing checklist

1. Edit `mod.cpp` — set `name`, `author`, `authorID` to yours.
2. Optionally rename the `CfgPatches` class in
   `config.cpp` to something unique to
   you, so two voice packs can't collide. **Do not rename the
   `DialogueFW_<VoiceLineID>_SoundSet` entries** — the scripts look those
   up by exact name.
3. Drop your `.ogg` files in, run `generate_soundsets.bat`.
4. Pack with Addon Builder (`SourceDir` = this folder), signed with your key.
5. Publish to the Workshop under your own account.
6. Put your `.bikey` in your server's `keys/` folder.

## Why the audio can't just live on the server



Short answer: **the audio has to reach the player's machine, and the only
route to a player's machine is the Steam Workshop.**

- Sound playback is client-side. The client is what plays the line.
- `CfgSoundSets` / `CfgSoundShaders` are config classes read from packed
  addons at game start. There is no runtime API to register a new SoundSet
  from a loose file, and nothing in `$profile:` is ever sent to clients —
  that folder is server-side only.
- So a `.ogg` sitting on the server can never be heard by anyone. It has
  to be inside a mod the client downloads.

This is a DayZ/Enfusion distribution constraint, not a limitation of this
mod — any voice mod, including ZenExpansionAudioAI, works the same way.
Anyone claiming otherwise is describing server-side sound (like ambient
triggers), which is a different system that can't do NPC dialogue.

What the split **does** save you: the SoundSets addon is tiny and separate,
so you repack and republish only this one. The scripts addon is never
touched, so you never re-sign or re-upload it, and you stay on the upstream
version for updates and bug fixes.

## Step by step

1. Export the line as mono 44.1 kHz `.ogg`.
2. Put it in `data/audio/dialogues/` (e.g. `peter_greeting_1.ogg`).
3. Add a `CfgSoundShaders` entry pointing at it (no file extension in the
   path).
4. Add a matching `CfgSoundSets` entry named
   `DialogueFW_<VoiceLineID>_SoundSet`, listing that shader.
5. Reference the same `<VoiceLineID>` in your tree JSON — unless it's one
   of the generated quest IDs above, which are matched automatically.
6. Repack **only this addon**. Redistribute it next to the unchanged
   scripts addon.

## Why paths include the mod folder

Addon Builder's `SourceDir` is the whole project root, so files land inside
the packed PBO at
`DialogueFramework\data\...`. The
`samples[]` paths must match that layout exactly. A missing
`addons/<addon>/` segment here is the same class of bug that once stopped
every script in this project from compiling — if audio silently fails and
the SoundSet name is definitely right, check this next.

## Talk animation

Nothing to configure. Whenever a line plays, the NPC's mouth moves for the
clip's duration automatically — the scripts read the clip length and drive
the animation over an RPC. Lines cut short (player clicks through or closes
the window) stop the animation immediately.
